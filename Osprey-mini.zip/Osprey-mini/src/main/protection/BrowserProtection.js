/*
 * Osprey - a browser extension that protects you from malicious websites.
 * Copyright (C) 2025 Foulest (https://github.com/Foulest)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */
"use strict";

// Main object for managing browser protection functionality
const BrowserProtection = (() => {

    // Map to store AbortControllers for each tab
    let tabAbortControllers = new Map();

    // API keys for various protection services
    let gDataKey;
    let smartScreenKey;

    /**
     * Initializes the API keys for various protection services.
     *
     * The key values aren't meant to be secretive, but this might stop secret sniffing bots.
     */
    function initializeKeys() {
        gDataKey = atob("MS4xNC4wIDI1LjUuMTcuMzM1IDEyOS4wLjAuMA==");
        smartScreenKey = atob("MzgxZGRkMWUtZTYwMC00MmRlLTk0ZWQtOGMzNGJmNzNmMTZk");
    }

    /**
     * Closes all open connections for a specific tab.
     *
     * @param {number} tabId - The ID of the tab for which to close connections.
     * @param {string} reason - The reason for closing the connections.
     */
    function closeOpenConnections(tabId, reason) {
        if (tabAbortControllers.has(tabId)) {
            tabAbortControllers.get(tabId).abort(reason); // Abort all pending requests for the tab
            tabAbortControllers.set(tabId, new AbortController()); // Create a new controller for future requests
        }
    }

    /**
     * Cleans up controllers for tabs that no longer exist.
     */
    function cleanupTabControllers() {
        // Browser API compatibility between Chrome and Firefox
        const browserAPI = typeof browser === 'undefined' ? chrome : browser;

        // Remove controllers for tabs that no longer exist
        browserAPI.tabs.query({}, tabs => {
            const activeTabIds = new Set(tabs.map(tab => tab.id));

            for (const tabId of tabAbortControllers.keys()) {
                if (!activeTabIds.has(tabId)) {
                    tabAbortControllers.delete(tabId);
                    console.debug(`Removed controller for tab ID: ${tabId}`);
                }
            }
        });
    }

    return {
        initializeKeys,

        /**
         * Abandons all pending requests for a specific tab.
         *
         * @param {number} tabId - The ID of the tab for which to abandon requests.
         * @param {string} reason - The reason for abandoning the requests.
         */
        abandonPendingRequests: function (tabId, reason) {
            closeOpenConnections(tabId, reason);
        },

        /**
         * Checks if a URL is malicious or trusted.
         *
         * @param {number} tabId - The ID of the tab that initiated the request.
         * @param {string} url - The URL to check.
         * @param {function} callback - The callback function to handle the result.
         */
        checkIfUrlIsMalicious: function (tabId, url, callback) {
            // Return early if any of the parameters are missing
            if (!tabId || !url || !callback) {
                return;
            }

            // Capture the current time for response measurement
            const startTime = (new Date()).getTime();

            // Parse the URL to extract the hostname and pathname
            const urlObject = new URL(url);
            const urlHostname = urlObject.hostname;
            const urlPathname = urlObject.pathname;

            // The non-filtering URL used for DNS lookups
            const nonFilteringURL = `https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(urlHostname)}`;

            // Ensure there is an AbortController for the tab
            if (!tabAbortControllers.has(tabId)) {
                tabAbortControllers.set(tabId, new AbortController());
            }

            // Get the signal from the current AbortController
            const signal = tabAbortControllers.get(tabId).signal;


            /**
             * Checks the URL with G DATA's API.
             *
             * @param {Object} settings - The settings object containing user preferences.
             */
            async function checkUrlWithGDATA(settings) {
                // Checks if the provider is enabled
                if (!settings.gDataEnabled) {
                    return;
                }

                // Checks if the URL is in the allowed cache
                if (isUrlInAllowedCache(urlObject, urlHostname, "gData")) {
                    console.debug(`[G DATA] URL is already allowed: ${url}`);
                    callback(new ProtectionResult(url, ProtectionResult.ResultType.KNOWN_SAFE, ProtectionResult.ResultOrigin.G_DATA), (new Date()).getTime() - startTime);
                    return;
                }

                // Checks if the URL is in the blocked cache
                if (isUrlInBlockedCache(urlObject, urlHostname, "gData")) {
                    console.debug(`[G DATA] URL is already blocked: ${url}`);
                    callback(new ProtectionResult(url, BrowserProtection.cacheManager.getBlockedResultType(url, "gData"), ProtectionResult.ResultOrigin.G_DATA), (new Date()).getTime() - startTime);
                    return;
                }

                // Checks if the URL is in the processing cache
                if (isUrlInProcessingCache(urlObject, urlHostname, "gData")) {
                    console.debug(`[G DATA] URL is already processing: ${url}`);
                    callback(new ProtectionResult(url, ProtectionResult.ResultType.WAITING, ProtectionResult.ResultOrigin.G_DATA), (new Date()).getTime() - startTime);
                    return;
                }

                // Adds the URL to the processing cache to prevent duplicate requests
                BrowserProtection.cacheManager.addUrlToProcessingCache(urlObject, "gData", tabId);

                // Adds a small delay to prevent overwhelming the API
                // Ignored if all official partners are disabled
                if (settings.adGuardSecurityEnabled || settings.adGuardFamilyEnabled ||
                    settings.alphaMountainEnabled || settings.controlDSecurityEnabled ||
                    settings.controlDFamilyEnabled || settings.precisionSecEnabled) {
                    await new Promise(resolve => setTimeout(resolve, 100));
                }

                const apiUrl = "https://dlarray-bp-europ-secsrv069.gdatasecurity.de/url/v3";

                const payload = {
                    "REVOKEID": 0,
                    "CLIENT": "EXED",
                    "CLV": gDataKey,
                    "URLS": [url]
                };

                try {
                    const response = await fetch(apiUrl, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(payload),
                        signal
                    });

                    // Return early if the response is not OK
                    if (!response.ok) {
                        console.warn(`[G DATA] Returned early: ${response.status}`);
                        callback(new ProtectionResult(url, ProtectionResult.ResultType.FAILED, ProtectionResult.ResultOrigin.G_DATA), (new Date()).getTime() - startTime);
                        return;
                    }

                    const data = await response.text();

                    // Phishing
                    if (data.includes("\"PHISHING\"")) {
                        console.debug(`[G DATA] Added URL to blocked cache: ${url}`);
                        BrowserProtection.cacheManager.addUrlToBlockedCache(urlObject, "gData", ProtectionResult.ResultType.PHISHING);
                        callback(new ProtectionResult(url, ProtectionResult.ResultType.PHISHING, ProtectionResult.ResultOrigin.G_DATA), (new Date()).getTime() - startTime);
                        return;
                    }

                    // Malicious
                    if (data.includes("\"MALWARE\"")) {
                        console.debug(`[G DATA] Added URL to blocked cache: ${url}`);
                        BrowserProtection.cacheManager.addUrlToBlockedCache(urlObject, "gData", ProtectionResult.ResultType.MALICIOUS);
                        callback(new ProtectionResult(url, ProtectionResult.ResultType.MALICIOUS, ProtectionResult.ResultOrigin.G_DATA), (new Date()).getTime() - startTime);
                        return;
                    }

                    // Safe/Allowed
                    if (data.includes("\"TRUSTED\"") ||
                        data.includes("\"WHITELIST\"") ||
                        data.includes("\"URLS\":[{}]}")) {
                        console.debug(`[G DATA] Added URL to allowed cache: ${url}`);
                        BrowserProtection.cacheManager.addUrlToAllowedCache(urlObject, "gData");
                        callback(new ProtectionResult(url, ProtectionResult.ResultType.ALLOWED, ProtectionResult.ResultOrigin.G_DATA), (new Date()).getTime() - startTime);
                        return;
                    }

                    // Unexpected result
                    console.warn(`[G DATA] Returned an unexpected result for URL ${url}: ${data}`);
                    callback(new ProtectionResult(url, ProtectionResult.ResultType.ALLOWED, ProtectionResult.ResultOrigin.G_DATA), (new Date()).getTime() - startTime);
                } catch (error) {
                    console.debug(`[G DATA] Failed to check URL ${url}: ${error}`);
                    callback(new ProtectionResult(url, ProtectionResult.ResultType.FAILED, ProtectionResult.ResultOrigin.G_DATA), (new Date()).getTime() - startTime);
                }
            }

            /**
             * Checks the URL with SmartScreen's API.
             *
             * @param {Object} settings - The settings object containing user preferences.
             */
            async function checkUrlWithSmartScreen(settings) {
                // Checks if the provider is enabled
                if (!settings.smartScreenEnabled) {
                    return;
                }

                // Checks if the URL is in the allowed cache
                if (isUrlInAllowedCache(urlObject, urlHostname, "smartScreen")) {
                    console.debug(`[SmartScreen] URL is already allowed: ${url}`);
                    callback(new ProtectionResult(url, ProtectionResult.ResultType.KNOWN_SAFE, ProtectionResult.ResultOrigin.SMARTSCREEN), (new Date()).getTime() - startTime);
                    return;
                }

                // Checks if the URL is in the blocked cache
                if (isUrlInBlockedCache(urlObject, urlHostname, "smartScreen")) {
                    console.debug(`[SmartScreen] URL is already blocked: ${url}`);
                    callback(new ProtectionResult(url, BrowserProtection.cacheManager.getBlockedResultType(url, "smartScreen"), ProtectionResult.ResultOrigin.SMARTSCREEN), (new Date()).getTime() - startTime);
                    return;
                }

                // Checks if the URL is in the processing cache
                if (isUrlInProcessingCache(urlObject, urlHostname, "smartScreen")) {
                    console.debug(`[SmartScreen] URL is already processing: ${url}`);
                    callback(new ProtectionResult(url, ProtectionResult.ResultType.WAITING, ProtectionResult.ResultOrigin.SMARTSCREEN), (new Date()).getTime() - startTime);
                    return;
                }

                // Adds the URL to the processing cache to prevent duplicate requests
                BrowserProtection.cacheManager.addUrlToProcessingCache(urlObject, "smartScreen", tabId);

                // Adds a small delay to prevent overwhelming the API
                // Ignored if all official partners are disabled
                if (settings.adGuardSecurityEnabled || settings.adGuardFamilyEnabled ||
                    settings.alphaMountainEnabled || settings.controlDSecurityEnabled ||
                    settings.controlDFamilyEnabled || settings.precisionSecEnabled) {
                    await new Promise(resolve => setTimeout(resolve, 100));
                }

                // Prepare request data
                const requestData = JSON.stringify({
                    destination: {
                        uri: UrlHelpers.normalizeHostname(urlHostname + urlPathname)
                    }
                });

                // Generate the hash and authorization header
                const {hash, key} = SmartScreenUtil.hash(requestData);
                const authHeader = `SmartScreenHash ${btoa(JSON.stringify({
                    authId: smartScreenKey,
                    hash,
                    key
                }))}`;

                try {
                    const response = await fetch("https://bf.smartscreen.microsoft.com/api/browser/Navigate/1", {
                        method: "POST",
                        credentials: "omit",
                        headers: {
                            "Content-Type": "application/json; charset=utf-8",
                            Authorization: authHeader
                        },
                        body: requestData,
                        signal
                    });

                    // Return early if the response is not OK
                    if (!response.ok) {
                        console.warn(`[SmartScreen] Returned early: ${response.status}`);
                        callback(new ProtectionResult(url, ProtectionResult.ResultType.FAILED, ProtectionResult.ResultOrigin.SMARTSCREEN), (new Date()).getTime() - startTime);
                        return;
                    }

                    const data = await response.json();
                    const {responseCategory} = data;

                    switch (responseCategory) {
                        case "TechScam":
                        case "Phishing":
                            console.debug(`[SmartScreen] Added URL to blocked cache: ${url}`);
                            BrowserProtection.cacheManager.addUrlToBlockedCache(urlObject, "smartScreen", ProtectionResult.ResultType.PHISHING);
                            callback(new ProtectionResult(url, ProtectionResult.ResultType.PHISHING, ProtectionResult.ResultOrigin.SMARTSCREEN), (new Date()).getTime() - startTime);
                            break;

                        case "Exploit":
                        case "Malicious":
                            console.debug(`[SmartScreen] Added URL to blocked cache: ${url}`);
                            BrowserProtection.cacheManager.addUrlToBlockedCache(urlObject, "smartScreen", ProtectionResult.ResultType.MALICIOUS);
                            callback(new ProtectionResult(url, ProtectionResult.ResultType.MALICIOUS, ProtectionResult.ResultOrigin.SMARTSCREEN), (new Date()).getTime() - startTime);
                            break;

                        case "Untrusted":
                            console.debug(`[SmartScreen] Added URL to blocked cache: ${url}`);
                            BrowserProtection.cacheManager.addUrlToBlockedCache(urlObject, "smartScreen", ProtectionResult.ResultType.UNTRUSTED);
                            callback(new ProtectionResult(url, ProtectionResult.ResultType.UNTRUSTED, ProtectionResult.ResultOrigin.SMARTSCREEN), (new Date()).getTime() - startTime);
                            break;

                        case "Allowed":
                            console.debug(`[SmartScreen] Added URL to allowed cache: ${url}`);
                            BrowserProtection.cacheManager.addUrlToAllowedCache(urlObject, "smartScreen");
                            callback(new ProtectionResult(url, ProtectionResult.ResultType.ALLOWED, ProtectionResult.ResultOrigin.SMARTSCREEN), (new Date()).getTime() - startTime);
                            break;

                        default:
                            console.warn(`[SmartScreen] Returned an unexpected result for URL ${url}: ${JSON.stringify(data)}`);
                            callback(new ProtectionResult(url, ProtectionResult.ResultType.ALLOWED, ProtectionResult.ResultOrigin.SMARTSCREEN), (new Date()).getTime() - startTime);
                            break;
                    }
                } catch (error) {
                    console.debug(`[SmartScreen] Failed to check URL ${url}: ${error}`);
                    callback(new ProtectionResult(url, ProtectionResult.ResultType.FAILED, ProtectionResult.ResultOrigin.SMARTSCREEN), (new Date()).getTime() - startTime);
                }
            }

            /**
             * Checks the URL with Norton's API.
             *
             * @param {Object} settings - The settings object containing user preferences.
             */
            async function checkUrlWithNorton(settings) {
                // Checks if the provider is enabled
                if (!settings.nortonEnabled) {
                    return;
                }

                // Checks if the URL is in the allowed cache
                if (isUrlInAllowedCache(urlObject, urlHostname, "norton")) {
                    console.debug(`[Norton] URL is already allowed: ${url}`);
                    callback(new ProtectionResult(url, ProtectionResult.ResultType.KNOWN_SAFE, ProtectionResult.ResultOrigin.NORTON), (new Date()).getTime() - startTime);
                    return;
                }

                // Checks if the URL is in the blocked cache
                if (isUrlInBlockedCache(urlObject, urlHostname, "norton")) {
                    console.debug(`[Norton] URL is already blocked: ${url}`);
                    callback(new ProtectionResult(url, BrowserProtection.cacheManager.getBlockedResultType(url, "norton"), ProtectionResult.ResultOrigin.NORTON), (new Date()).getTime() - startTime);
                    return;
                }

                // Checks if the URL is in the processing cache
                if (isUrlInProcessingCache(urlObject, urlHostname, "norton")) {
                    console.debug(`[Norton] URL is already processing: ${url}`);
                    callback(new ProtectionResult(url, ProtectionResult.ResultType.WAITING, ProtectionResult.ResultOrigin.NORTON), (new Date()).getTime() - startTime);
                    return;
                }

                // Adds the URL to the processing cache to prevent duplicate requests
                BrowserProtection.cacheManager.addUrlToProcessingCache(urlObject, "norton", tabId);

                // Adds a small delay to prevent overwhelming the API
                // Ignored if all official partners are disabled
                if (settings.adGuardSecurityEnabled || settings.adGuardFamilyEnabled ||
                    settings.alphaMountainEnabled || settings.controlDSecurityEnabled ||
                    settings.controlDFamilyEnabled || settings.precisionSecEnabled) {
                    await new Promise(resolve => setTimeout(resolve, 100));
                }

                const apiUrl = `https://ratings-wrs.norton.com/brief?url=${encodeURIComponent(url)}`;

                try {
                    const response = await fetch(apiUrl, {
                        method: "GET",
                        signal
                    });

                    // Return early if the response is not OK
                    if (!response.ok) {
                        console.warn(`[Norton] Returned early: ${response.status}`);
                        callback(new ProtectionResult(url, ProtectionResult.ResultType.FAILED, ProtectionResult.ResultOrigin.NORTON), (new Date()).getTime() - startTime);
                        return;
                    }

                    const data = await response.text();

                    // Malicious
                    if (data.includes('r="b"')) {
                        console.debug(`[Norton] Added URL to blocked cache: ${url}`);
                        BrowserProtection.cacheManager.addUrlToBlockedCache(urlObject, "norton", ProtectionResult.ResultType.MALICIOUS);
                        callback(new ProtectionResult(url, ProtectionResult.ResultType.MALICIOUS, ProtectionResult.ResultOrigin.NORTON), (new Date()).getTime() - startTime);
                        return;
                    }

                    // Safe/Trusted
                    if (data.includes('r="g"') ||
                        data.includes('r="r"') ||
                        data.includes('r="w"') ||
                        data.includes('r="u"')) {
                        console.debug(`[Norton] Added URL to allowed cache: ${url}`);
                        BrowserProtection.cacheManager.addUrlToAllowedCache(urlObject, "norton");
                        callback(new ProtectionResult(url, ProtectionResult.ResultType.ALLOWED, ProtectionResult.ResultOrigin.NORTON), (new Date()).getTime() - startTime);
                        return;
                    }

                    // Unexpected result
                    console.warn(`[Norton] Returned an unexpected result for URL ${url}: ${data}`);
                    callback(new ProtectionResult(url, ProtectionResult.ResultType.ALLOWED, ProtectionResult.ResultOrigin.NORTON), (new Date()).getTime() - startTime);
                } catch (error) {
                    console.debug(`[Norton] Failed to check URL ${url}: ${error}`);
                    callback(new ProtectionResult(url, ProtectionResult.ResultType.FAILED, ProtectionResult.ResultOrigin.NORTON), (new Date()).getTime() - startTime);
                }
            }




            /**
             * Encodes a DNS query for the given domain and type.
             *
             * @param {string} domain - The domain to encode.
             * @param {number} type - The type of DNS record (default is 1 for A record).
             * @return {string} - The base64url encoded DNS query.
             */
            function encodeDnsQuery(domain, type = 1) {
                // Creates DNS query components
                const header = new Uint8Array([
                    0x00, 0x00, // ID (0)
                    0x01, 0x00, // Flags: standard query
                    0x00, 0x01, // QDCOUNT: 1 question
                    0x00, 0x00, // ANCOUNT: 0 answers
                    0x00, 0x00, // NSCOUNT: 0 authority records
                    0x00, 0x00  // ARCOUNT: 0 additional records
                ]);

                // Encodes domain parts
                const domainParts = domain.split('.');
                let domainBuffer = [];

                for (const part of domainParts) {
                    domainBuffer.push(part.length);

                    for (let i = 0; i < part.length; i++) {
                        domainBuffer.push(part.charCodeAt(i));
                    }
                }

                // Adds terminating zero
                domainBuffer.push(0);

                // Adds QTYPE and QCLASS
                domainBuffer.push(0x00, type); // QTYPE (1 = A record)
                domainBuffer.push(0x00, 0x01); // QCLASS (1 = IN)

                // Combines the header and domain parts
                const dnsPacket = new Uint8Array([...header, ...domainBuffer]);

                // Encodes and returns the results
                return btoa(String.fromCharCode(...dnsPacket))
                    .replace(/\+/g, '-')
                    .replace(/\//g, '_')
                    .replace(/=+$/, '');
            }

            /**
             * Checks if the URL is in the allowed caches.
             *
             * @param urlObject - The URL object.
             * @param hostname - The hostname of the URL.
             * @param provider - The provider to check the allowed cache against.
             * @returns {boolean} - True if the URL is in the allowed cache, false otherwise.
             */
            function isUrlInAllowedCache(urlObject, hostname, provider) {
                return BrowserProtection.cacheManager.isUrlInAllowedCache(urlObject, provider) ||
                    BrowserProtection.cacheManager.isStringInAllowedCache(`${hostname} (allowed)`, provider);
            }

            /**
             * Checks if the URL is in the blocked caches.
             *
             * @param urlObject - The URL object.
             * @param hostname - The hostname of the URL.
             * @param provider - The provider to check the blocked cache against.
             * @returns {boolean} - True if the URL is in the blocked cache, false otherwise.
             */
            function isUrlInBlockedCache(urlObject, hostname, provider) {
                return BrowserProtection.cacheManager.isUrlInBlockedCache(urlObject, provider);
            }

            /**
             * Checks if the URL is in the processing caches.
             *
             * @param urlObject - The URL object.
             * @param hostname - The hostname of the URL.
             * @param provider - The provider to check the processing cache against.
             * @returns {boolean} - True if the URL is in the processing cache, false otherwise.
             */
            function isUrlInProcessingCache(urlObject, hostname, provider) {
                return BrowserProtection.cacheManager.isUrlInProcessingCache(urlObject, provider);
            }

            // Call all the check functions asynchronously
            Settings.get(settings => {
                // Non-Partnered Providers
                checkUrlWithGDATA(settings);
                checkUrlWithSmartScreen(settings);
                checkUrlWithNorton(settings);
            });

            // Cleans up controllers for tabs that no longer exist
            cleanupTabControllers();
        }
    };
})();

// Initializes the cache manager
BrowserProtection.cacheManager = new CacheManager();

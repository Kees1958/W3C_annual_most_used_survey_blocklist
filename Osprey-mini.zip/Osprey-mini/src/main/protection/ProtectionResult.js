/*
 * Osprey - a browser extension that protects you from malicious websites.
 * Copyright (C) 2025 Foulest (https://github.com/Foulest)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */
"use strict";

class ProtectionResult {

    /**
     * Constructor function for creating a browser protection result object.
     *
     * @param {string} urlChecked - The URL that was checked.
     * @param {string} resultType - The result type of the protection check (e.g., "allowed", "malicious").
     * @param {number} resultOrigin - The origin of the result (e.g., from endpoint or known top site).
     */
    constructor(urlChecked, resultType, resultOrigin) {
        this.url = urlChecked;
        this.result = resultType;
        this.origin = resultOrigin;
    }
}

ProtectionResult.ResultType = {
    KNOWN_SAFE: "Known Safe",
    FAILED: "Failed",
    WAITING: "Waiting",
    ALLOWED: "Allowed",
    MALICIOUS: "Malicious",
    PHISHING: "Phishing",
    UNTRUSTED: "Untrusted",
    ADULT_CONTENT: "Adult Content",
};

ProtectionResult.ResultOrigin = {
    UNKNOWN: 0,

    // Non-Partnered Providers
    G_DATA: 7,
    SMARTSCREEN: 20,
    NORTON: 21,

};

ProtectionResult.ResultOriginNames = {
    0: "Unknown",

    // Non-Partnered Providers
    7: "G DATA Web Protection",
    20: "Microsoft SmartScreen",
    21: "Norton Safe Web",

};

ProtectionResult.ShortOriginNames = {
    0: "Unknown",

    // Non-Partnered Providers
    7: "G DATA",
    20: "SmartScreen",
    21: "Norton",
 
};

ProtectionResult.CacheOriginNames = {
    0: "unknown",
  
    // Non-Partnered Providers
    7: "gData",
    20: "smartScreen",
    21: "norton",
};

/*
 * Osprey - a browser extension that protects you from malicious websites.
 * Copyright (C) 2025 Foulest (https://github.com/Foulest)
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */
"use strict";

const Messages = {

    MessageType: {
        // Blocked Counter Actions
        BLOCKED_COUNTER_PING: "blockedCounterPing",
        BLOCKED_COUNTER_PONG: "blockedCounterPong",

        // Block Page Actions
        CONTINUE_TO_SAFETY: "continueToSafety",
        CONTINUE_TO_SITE: "continueToSite",
        REPORT_SITE: "reportSite",
        ALLOW_SITE: "allowSite",

        // Official Partners
        ADGUARD_SECURITY_TOGGLED: "adGuardSecurityToggled",
        ADGUARD_FAMILY_TOGGLED: "adGuardFamilyToggled",
        ALPHAMOUNTAIN_TOGGLED: "alphaMountainToggled",
        CONTROL_D_SECURITY_TOGGLED: "controlDSecurityToggled",
        CONTROL_D_FAMILY_TOGGLED: "controlDFamilyToggled",
        PRECISIONSEC_TOGGLED: "precisionSecToggled",

        // Non-Partnered Providers
        G_DATA_TOGGLED: "gDataToggled",
        CERT_EE_TOGGLED: "certEEToggled",
        CIRA_SECURITY_TOGGLED: "ciraSecurityToggled",
        CIRA_FAMILY_TOGGLED: "ciraFamilyToggled",
        CLEANBROWSING_SECURITY_TOGGLED: "cleanBrowsingSecurityToggled",
        CLEANBROWSING_FAMILY_TOGGLED: "cleanBrowsingFamilyToggled",
        CLEANBROWSING_ADULT_TOGGLED: "cleanBrowsingAdultToggled",
        CLOUDFLARE_SECURITY_TOGGLED: "cloudflareSecurityToggled",
        CLOUDFLARE_FAMILY_TOGGLED: "cloudflareFamilyToggled",
        DNS0_SECURITY_TOGGLED: "dns0SecurityToggled",
        DNS0_KIDS_TOGGLED: "dns0KidsToggled",
        DNS4EU_SECURITY_TOGGLED: "dns4EUSecurityToggled",
        DNS4EU_FAMILY_TOGGLED: "dns4EUFamilyToggled",
        SMARTSCREEN_TOGGLED: "smartScreenToggled",
        NORTON_TOGGLED: "nortonToggled",
        OPENDNS_SECURITY_TOGGLED: "openDNSSecurityToggled",
        OPENDNS_FAMILY_SHIELD_TOGGLED: "openDNSFamilyShieldToggled",
        QUAD9_TOGGLED: "quad9Toggled",
        SWITCH_CH_TOGGLED: "switchCHToggled",
    }
};

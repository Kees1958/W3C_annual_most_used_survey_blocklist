/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

*******************************************************************************/
/*
 * ruleset-manager.js — Dynamic DNR rule management
 *
 * Public interface:
 *   filteringModesToDNR(modes)   — writes trusted-directive allowAllRequests rules
 *   updateDynamicRules()         — cleans up legacy dynamic rules on version change
 *   updateUserRules()            — registers compiled sandbox DNR rules (cap: USER_RULES_MAX)
 *   getEffectiveUserRules()      — returns currently registered sandbox DNR rules
 *   updateSecurityRules()        — applies/removes security toggle DNR rules
 *
 * Rule ID ranges: see js/core/dnr-budgets.js for the authoritative allocation table.
 *
 * ── STATE / GUARDS (uBol-stripped-code-review.md §1 retrofit) ───────────────
 * No session, no phases: every exported function here is a standalone,
 * idempotent read-DNR/compute/write-DNR operation — there's no multi-step
 * lifecycle to model with a phase enum (contrast block-monitor.js, which
 * genuinely has one). The state-vector pattern (B3a) is deliberately NOT
 * applied here for that reason — forcing a phase field onto functions that
 * don't have phases would add fake complexity, not real clarity.
 *
 * The one piece of real state this module owns:
 *   regexValidationCache {Map}  — bounded to REGEX_VALIDATION_CACHE_MAX (500)
 *     entries via delete-then-set-refreshes-recency + evict-oldest-on-
 *     overflow (see pruneInvalidRegexRules() below). In-memory only, lost on
 *     SW restart — safe, since it's purely a cache: a cold cache just means
 *     the next sandbox save re-validates regexes it already validated
 *     before, not a correctness issue.
 */


// Static DNR rulesets are always fully enabled in this build (rule_resources
// is [] in the manifest). This file now only manages:
//   1. filteringModesToDNR  — translate mode Sets → DNR allowAllRequests rules
//   2. updateDynamicRules   — clean up legacy dynamic rules on version change
//   3. updateUserRules      — register compiled sandbox DNR rules
//   4. getEffectiveUserRules — read current sandbox rule slot from dynamic rules

import {
    localRead, localRemove, localWrite,
} from '../data/ext.js';

import { dnr } from '../data/ext-compat.js';
import { securityConfig, securityAllowlist, rulesetConfig } from '../data/config.js';
import { MATRIX_DETECT_CONFIG } from './matrix-detect.js';
import { DDNS_FREEHOSTING_DOMAINS, DDNS_FREEHOSTING_REGEX_PATTERNS } from '../data/ddns-freehosting-list.js';
import { LOGIN_WITH_SCRIPT_DOMAINS, LOGIN_WITH_FRAME_DOMAINS } from '../data/login-with-exceptions.js';

// Parse a comma/newline-separated allowlist string into a clean hostname array.
function parseAllowlistDomains(str) {
    if ( !str ) { return []; }
    return str.split(/[\s,]+/).map(h => h.trim().toLowerCase())
        .filter(h => h.length > 0 && !h.startsWith('#'));
}

import {
    SECURITY_RULES_BASE_ID,
    SECURITY_RULES_PRIORITY,
    SECURITY_PORT_ALLOW_PRIORITY,
    SECURITY_PORT_BLOCK_PRIORITY,
    BUILTIN_WHITELIST_RULES_PRIORITY,
    TRUSTED_DIRECTIVE_BASE_ID,
    TRUSTED_DIRECTIVE_PRIORITY,
    USER_RULES_BASE_ID,
    USER_RULES_MAX,
    USER_RULES_PRIORITY,
} from './dnr-budgets.js';

/******************************************************************************/

// Legacy realm — rule IDs below this were written by older builds and must be
// cleaned up on version change. Must stay below all current base IDs.
const SPECIAL_RULES_REALM = 5_000_000;

// Validated-regex cache — bounded to avoid unbounded memory growth on
// repeated sandbox saves. 500 entries is generous for a single-user build.
const REGEX_VALIDATION_CACHE_MAX = 500;
const regexValidationCache = new Map();

/******************************************************************************/

// Translate filtering mode Sets into a DNR allowAllRequests rule pair so the
// browser enforces per-hostname filtering decisions at the network layer.

export async function filteringModesToDNR(modes) {
    const noneHostnames = new Set([ ...modes.none ]);
    // modes.basic always carries a bookkeeping 'all-urls' member (see
    // js/core/filter-manager.js's registerCustomFilters() for the full
    // explanation and the real bug this same leak caused there). Harmless
    // here — dnr.setAllowAllRules() just gets one unmatchable 'all-urls'
    // domain string in its exclusion list — but stripped for consistency.
    const notNoneHostnames = new Set([ ...modes.basic ].filter(hn => hn !== 'all-urls'));
    const requestDomains = [];
    const excludedRequestDomains = [];
    const allowEverywhere = noneHostnames.has('all-urls');
    if ( allowEverywhere ) {
        excludedRequestDomains.push(...notNoneHostnames);
    } else {
        requestDomains.push(...noneHostnames);
    }
    return dnr.setAllowAllRules(
        TRUSTED_DIRECTIVE_BASE_ID,
        requestDomains.sort(),
        excludedRequestDomains.sort(),
        allowEverywhere,
        TRUSTED_DIRECTIVE_PRIORITY
    );
}

/******************************************************************************/

// Validate regex-based DNR rules against the browser's regex engine and
// remove any it rejects. Results are cached to avoid redundant API calls.

async function pruneInvalidRegexRules(rulesIn, rejected = []) {
    const validateRegex = regex => {
        return dnr.isRegexSupported({ regex, isCaseSensitive: false }).then(result => {
            // Cache: delete-then-set refreshes recency for FIFO eviction.
            regexValidationCache.delete(regex);
            regexValidationCache.set(regex, result?.reason || true);
            if ( regexValidationCache.size > REGEX_VALIDATION_CACHE_MAX ) {
                regexValidationCache.delete(regexValidationCache.keys().next().value);
            }
            if ( result.isSupported ) { return true; }
            rejected.push({ regex, reason: result?.reason });
            return false;
        });
    };

    const toCheck = [];
    for ( const rule of rulesIn ) {
        if ( rule.condition?.regexFilter === undefined ) {
            toCheck.push(true);
            continue;
        }
        const { regexFilter } = rule.condition;
        const cached = regexValidationCache.get(regexFilter);
        if ( cached !== undefined ) {
            toCheck.push(cached === true);
            if ( cached !== true ) {
                rejected.push({ regex: regexFilter, reason: cached });
            }
            continue;
        }
        toCheck.push(validateRegex(regexFilter));
    }

    const isValid = await Promise.all(toCheck);
    return rulesIn.filter((v, i) => isValid[i]);
}

/******************************************************************************/

// On version change: remove any legacy dynamic rules (regex rules from old
// static rulesets) that are no longer relevant, and clear leftover session
// rules from removed features (e.g. strict-block).

export async function updateDynamicRules() {
    const currentRules = await dnr.getDynamicRules();

    // Collect IDs of legacy rules below the special-rules boundary.
    // Rules at or above SPECIAL_RULES_REALM are managed elsewhere (trusted
    // directive rules, user rules) and must not be touched here.
    const removeRuleIds = [];
    for ( const rule of currentRules ) {
        if ( rule.id >= SPECIAL_RULES_REALM ) { continue; }
        removeRuleIds.push(rule.id);
    }

    if ( removeRuleIds.length !== 0 ) {
        await dnr.updateDynamicRules({ removeRuleIds }).catch(reason => {
            console.error(`[uBlock-Dynamic] updateDynamicRules/${reason}`);
        });
    }

    // Clear any leftover session rules (strict-block feature was removed).
    const sessionRules = await dnr.getSessionRules();
    if ( sessionRules.length !== 0 ) {
        const removeSessionRuleIds = sessionRules.map(r => r.id);
        await dnr.updateSessionRules({ removeRuleIds: removeSessionRuleIds });
    }
}

/******************************************************************************/

// Read the current sandbox-rule slot from the dynamic rule set.
// Rules below USER_RULES_BASE_ID belong to other subsystems.

export async function getEffectiveUserRules() {
    const allRules = await dnr.getDynamicRules();
    return allRules.filter(rule => rule.id >= USER_RULES_BASE_ID);
}

/******************************************************************************/

// Apply compiled sandbox DNR rules to the dynamic rule slot.
// Removes all existing user-slot rules first (separately, to avoid a failed
// add blocking the removal of stale rules).

export async function updateUserRules() {
    const [
        currentUserRules,
        sandboxRules,
    ] = await Promise.all([
        getEffectiveUserRules(),
        localRead('sandboxFilters.dnrRules'),
    ]);

    const rules = Array.isArray(sandboxRules) ? sandboxRules.slice() : [];

    // Elevate priority so sandbox rules win over static ruleset rules.
    for ( const rule of rules ) {
        rule.priority = (rule.priority || 1) + USER_RULES_PRIORITY;
    }

    const removeRuleIds = currentUserRules.map(r => r.id);
    const rejectedRegexes = [];
    const validRules = await pruneInvalidRegexRules(rules, rejectedRegexes);
    // Enforce cap — Chrome allows 30 000 safe dynamic rules total; staying
    // within USER_RULES_MAX prevents sandbox rules from starving other slots.
    const addRules = validRules.slice(0, USER_RULES_MAX);
    const out = { added: 0, removed: 0, errors: [] };

    for ( const e of rejectedRegexes ) {
        out.errors.push(`regexFilter: ${e.regex} → ${e.reason}`);
    }
    if ( validRules.length > USER_RULES_MAX ) {
        out.errors.push(`${validRules.length - USER_RULES_MAX} rules dropped — exceeded USER_RULES_MAX (${USER_RULES_MAX})`);
    }

    if ( removeRuleIds.length === 0 && addRules.length === 0 ) {
        await localRemove('userDnrRuleCount');
        return out;
    }

    let ruleId = 0;
    for ( const rule of addRules ) {
        rule.id = USER_RULES_BASE_ID + ruleId++;
    }

    // Remove then add in two separate calls so a bad rule in addRules cannot
    // prevent removal of the stale rules.
    try {
        await dnr.updateDynamicRules({ removeRuleIds });
        await dnr.updateDynamicRules({ addRules });
        out.added = addRules.length;
        out.removed = removeRuleIds.length;
    } catch(reason) {
        console.error(`[uBlock-Dynamic] updateUserRules/${reason}`);
        out.errors.push(`${reason}`);
    } finally {
        const remaining = await getEffectiveUserRules();
        if ( remaining.length === 0 ) {
            await localRemove('userDnrRuleCount');
        } else {
            await localWrite('userDnrRuleCount', addRules.length);
        }
    }

    return out;
}

/******************************************************************************/

// Apply DNR rules for the security tab toggles.
//
// Rule slot assignments:
//   SECURITY_RULES_BASE_ID + 0 : (removed v2.7 — was blockThirdPartyWebSockets)
//   SECURITY_RULES_BASE_ID + 1 : (removed v2.7 — was blockThirdPartyWebTransport)
//   SECURITY_RULES_BASE_ID + 2 : block pings & beacons — <a ping> + sendBeacon, all origins
//   SECURITY_RULES_BASE_ID + 3 : block plugin objects (all origins)
//   SECURITY_RULES_BASE_ID + 4 : (removed — was separate beacons slot, now merged into +2)
//   SECURITY_RULES_BASE_ID + 5 : (uBlock-Stripped-Dynamic) block suspicious 3P-links — punycode component
//   SECURITY_RULES_BASE_ID + 6 : block webbundle (all origins)
//   SECURITY_RULES_BASE_ID + 7 : (uBlock-Stripped-Dynamic) block suspicious 3P-links — IP-literal-host component
//   SECURITY_RULES_BASE_ID + 8 : (uBlock-Stripped-Dynamic) block suspicious 3P-links — non-standard-port ALLOW component (must outrank +9)
//   SECURITY_RULES_BASE_ID + 9 : (uBlock-Stripped-Dynamic) block suspicious 3P-links — non-standard-port BLOCK component
//   SECURITY_RULES_BASE_ID + 10: (uBlock-Stripped-Dynamic) block suspicious 3P-links — DDNS/free-hosting component (pattern d)
//   SECURITY_RULES_BASE_ID + 11: (uBlock-Stripped-Dynamic) login-with SSO exemption — script component
//   SECURITY_RULES_BASE_ID + 12: (uBlock-Stripped-Dynamic) login-with SSO exemption — sub_frame component
//   SECURITY_RULES_BASE_ID + 13: (uBlock-Stripped-Dynamic) block suspicious 3P-links — DDNS/free-hosting regex
//                                 component (wildcard-only source entries, e.g. byethost*.com, that cannot
//                                 be expressed as requestDomains — see js/data/ddns-freehosting-list.js).
//                                 LAST slot in the 14-slot Security toggle range (dnr-budgets.js) — fully
//                                 allocated as of this addition; a new slot needs a new ID range.
//   (GPC_RULES_BASE_ID entry REMOVED — Global Privacy Control removed as a
//    feature; see dnr-budgets.js's retired-range note for 12 000 000)
//
// WebRTC/WebGL/visibilitychange/clipboard are scriptlet-based toggles —
// applied via applySecurityScriptlets() in site-mode-manager.js.
//
// "Block suspicious 3P-links" is five independent conditions under one
// toggle (punycode / IP-literal host / non-standard port / known DDNS or
// free-hosting domain / known DDNS or free-hosting REGEX) — each its own
// rule rather than one combined regex, since DNR's RE2 engine has no
// negative lookahead (see js/core/matrix-detect.js's header): the
// non-standard-port check specifically needs an allow-then-block
// PRIORITY PAIR (+8 outranks +9), not a single regex, to express "block
// any explicit port except these four" — the same allow/block-by-priority
// composition 3P-Matrix-lite's own matrixRules overrides use. The 4th
// condition (DDNS/free-hosting, exact domains) is a plain domain-list
// match (requestDomains) — no priority pairing needed there, just its own
// rule (+10). The 5th condition (+13) exists alongside it for the small
// number of source-list entries that use a wildcard or ABP regex instead
// of a plain domain (DNR's requestDomains needs exact strings) — see
// js/data/ddns-freehosting-list.js's DDNS_FREEHOSTING_REGEX_PATTERNS.
//
// +11/+12 are INVERTED relative to every other slot here: enabled is
// `!securityConfig.blockLoginWith` (the exemption is ACTIVE unless the
// user checks "Block login-with" on the Filter (block) lists page — see
// js/data/login-with-exceptions.js's header for why this is a simple
// global on/off rather than the source spec's more ambitious per-site,
// user-initiated-login-only scoping). action: 'allow', priority
// BUILTIN_WHITELIST_RULES_PRIORITY (dnr-budgets.js) — same tier as the
// CRITICAL RESOURCE global exemption, since both are "this domain should
// win over passive blocking" cases.

export async function updateSecurityRules() {
    // isWorryFreeActive — independent copy of the exact same cycle-free-
    // read pattern already established twice for this identical class of
    // problem (js/core/scripting-manager.js's own isAutoDenySessionActive(),
    // itself documented as "one more independent copy of one string, same
    // 'must match exactly' posture as COOKIE_CLICKER_STORAGE_KEY" — kept
    // as a duplicate here too rather than importing across files that
    // don't currently depend on each other, for the same reasoning).
    const AUTO_DENY_STORAGE_KEY = 'cookieClicker.autoDeny';
    const autoDenyStored = await localRead(AUTO_DENY_STORAGE_KEY).catch(() => undefined);
    const isWorryFreeActive = typeof autoDenyStored === 'object' && autoDenyStored !== null && autoDenyStored.active === true;

    const currentRules = await dnr.getDynamicRules({
        ruleIds: [
            SECURITY_RULES_BASE_ID + 0,
            SECURITY_RULES_BASE_ID + 1,
            SECURITY_RULES_BASE_ID + 2,
            SECURITY_RULES_BASE_ID + 3,
            SECURITY_RULES_BASE_ID + 4,
            SECURITY_RULES_BASE_ID + 5,
            SECURITY_RULES_BASE_ID + 6,
            SECURITY_RULES_BASE_ID + 7,
            SECURITY_RULES_BASE_ID + 8,
            SECURITY_RULES_BASE_ID + 9,
            SECURITY_RULES_BASE_ID + 10,
            SECURITY_RULES_BASE_ID + 11,
            SECURITY_RULES_BASE_ID + 12,
            SECURITY_RULES_BASE_ID + 13,
        ],
    });
    const currentIds = new Set(currentRules.map(r => r.id));

    const removeRuleIds = [];
    const addRules = [];

    // Slots +0 and +1 (websocket/webtransport) were removed in v2.7.
    // Ensure any previously registered rules are cleaned up on upgrade.
    for ( const id of [ SECURITY_RULES_BASE_ID + 0, SECURITY_RULES_BASE_ID + 1, SECURITY_RULES_BASE_ID + 2, SECURITY_RULES_BASE_ID + 3, SECURITY_RULES_BASE_ID + 4 ] ) {
        if ( currentIds.has(id) ) { removeRuleIds.push(id); }
    }

    // Explicit-port allowlist for the non-standard-port check — single
    // source of truth is MATRIX_DETECT_CONFIG (js/core/matrix-detect.js),
    // imported rather than re-declared here, so the JS-side predicate
    // (used later for Matrix panel display) and this DNR rule can never
    // silently drift onto two different port lists.
    const allowedPorts = MATRIX_DETECT_CONFIG.ALLOWED_EXPLICIT_PORTS.join('|');

    // NOTE: an earlier version of this function built a matrixAllowedDomains
    // exemption list here (from getMatrixOverrides()) and threaded it into
    // every slot below as excludedRequestDomains, so a Matrix panel Allow
    // click would exempt a domain from these toggles too. Removed: once the
    // Matrix override model became per-site (site, domain) rather than a
    // flat global domain list (see matrix-block-rules.js's header), a flat
    // exemption list no longer made sense — "allowed on site A" isn't the
    // same fact as "allowed everywhere". The equivalent behavior now comes
    // for free from DNR priority alone: MATRIX_RULES_ALL_PRIORITY /
    // MATRIX_RULES_CODE_PRIORITY (dnr-budgets.js) are set higher than
    // SECURITY_RULES_PRIORITY, so a per-site Matrix allow rule already
    // outranks these toggles' block rules wherever both would otherwise
    // match — no manual coordination code needed in this file at all.

    const securitySlots = [
        {
            id: SECURITY_RULES_BASE_ID + 5,
            enabled: securityConfig.blockSuspicious3pLinks,
            regexFilter: '[./]xn--[^./]',
            thirdPartyOnly: true,
            allowlistKey: 'blockSuspicious3pLinks',
        },
        {
            id: SECURITY_RULES_BASE_ID + 6,
            enabled: securityConfig.blockWebBundles,
            resourceTypes: [ 'webbundle' ],
            thirdPartyOnly: false,
            allowlistKey: 'blockWebBundles',
        },
        {
            id: SECURITY_RULES_BASE_ID + 7,
            enabled: securityConfig.blockSuspicious3pLinks,
            // IPv4 dotted-quad OR bracketed IPv6, in the URL authority
            // position specifically (right after '://') — mirrors
            // matrix-detect.js's isIpLiteralHost() logic, expressed as a
            // regex since that's what DNR needs; kept as two alternatives
            // in one regexFilter rather than two separate rules, since
            // there's no priority interaction to express here (unlike the
            // port pair below).
            regexFilter: '^[a-z]+://(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}([:/]|$)|\\[[0-9a-fA-F:]+\\])',
            thirdPartyOnly: true,
            allowlistKey: 'blockSuspicious3pLinks',
        },
        {
            id: SECURITY_RULES_BASE_ID + 8,
            enabled: securityConfig.blockSuspicious3pLinks,
            action: 'allow',
            priority: SECURITY_PORT_ALLOW_PRIORITY,
            // Explicit standard port in the authority position — allowed
            // through, at higher priority than +9's general block below.
            regexFilter: `^[a-z]+://[^/]+:(${allowedPorts})([/]|$)`,
            thirdPartyOnly: true,
            allowlistKey: 'blockSuspicious3pLinks',
        },
        {
            id: SECURITY_RULES_BASE_ID + 9,
            enabled: securityConfig.blockSuspicious3pLinks,
            priority: SECURITY_PORT_BLOCK_PRIORITY,
            // Any explicit port in the authority position — +8 above
            // (higher priority) exempts the 4 standard ones first.
            regexFilter: '^[a-z]+://[^/]+:[0-9]{1,5}([/]|$)',
            thirdPartyOnly: true,
            allowlistKey: 'blockSuspicious3pLinks',
        },
        {
            id: SECURITY_RULES_BASE_ID + 10,
            // DDNS/free-hosting is now pattern d) of "Block suspicious
            // 3P-links" rather than its own separate toggle (folded in —
            // see securityConfig's own comment in config.js for why).
            enabled: securityConfig.blockSuspicious3pLinks,
            // Whole-domain match against the bundled snapshot (see
            // js/data/ddns-freehosting-list.js's header for why this is a
            // static list, not a runtime fetch).
            requestDomains: DDNS_FREEHOSTING_DOMAINS,
            // websocket + webtransport added 2026-08-08: the upstream
            // source list itself widened its own rule convention to
            // include websocket (see ddns-freehosting-list.js's 2026-08-08
            // refresh notes); webtransport added on top as our own
            // addition, same rationale (modern companion protocol to
            // websocket for third-party realtime connections). This
            // supersedes the project's older "never extend blocking
            // beyond sub_frame + script" convention for this specific
            // slot — that convention predates this source list adopting
            // its own considered position on scope (including an explicit
            // "excluded on purpose" list of domains too broadly legitimate
            // to safely include — see ddns-freehosting-list.js), so we now
            // defer to the source's own scoping decision here rather than
            // the older blanket rule.
            resourceTypes: [ 'sub_frame', 'script', 'websocket', 'webtransport' ],
            thirdPartyOnly: true,
            allowlistKey: 'blockSuspicious3pLinks',
        },
        {
            id: SECURITY_RULES_BASE_ID + 13,
            // 5th component of "Block suspicious 3P-links" — same toggle,
            // same enabled/allowlist gating as +10, but for source-list
            // entries that use a wildcard or ABP regex instead of a plain
            // domain (requestDomains needs exact strings — see
            // js/data/ddns-freehosting-list.js's header, point 3). One DNR
            // rule per pattern; currently just the one (byethost*.com).
            enabled: securityConfig.blockSuspicious3pLinks,
            regexFilter: DDNS_FREEHOSTING_REGEX_PATTERNS[0],
            resourceTypes: [ 'sub_frame', 'script', 'websocket', 'webtransport' ],
            thirdPartyOnly: true,
            allowlistKey: 'blockSuspicious3pLinks',
        },
        {
            id: SECURITY_RULES_BASE_ID + 11,
            // Inverted: enabled when the checkbox is OFF (default) — see
            // this function's own header comment above for the full
            // "+11/+12 are inverted" explanation. v8.3.16 — the manual
            // checkbox itself was removed from the dashboard (Filter
            // (block) lists pane); securityConfig.blockLoginWith now only
            // ever changes via the one-time migration below (stays at its
            // stored value, never newly set by a UI toggle again) or via
            // isWorryFreeActive — the exemption is force-disabled (login-
            // with popups blocked) for the duration of a Worry-free
            // session, same override pattern already established for
            // blockAdultNoEval/blockAdultFingerprinting (compiled-
            // filters.js's worryFreeOverride, v8.3.12) — reused here, not
            // reinvented, just applied at the DNR-rule level instead of
            // content-script registration since that's this feature's own
            // real mechanism.
            enabled: !(securityConfig.blockLoginWith === true || isWorryFreeActive),
            action: 'allow',
            priority: BUILTIN_WHITELIST_RULES_PRIORITY,
            requestDomains: LOGIN_WITH_SCRIPT_DOMAINS,
            resourceTypes: [ 'script' ],
            thirdPartyOnly: true,
        },
        {
            id: SECURITY_RULES_BASE_ID + 12,
            enabled: !(securityConfig.blockLoginWith === true || isWorryFreeActive),
            action: 'allow',
            priority: BUILTIN_WHITELIST_RULES_PRIORITY,
            requestDomains: LOGIN_WITH_FRAME_DOMAINS,
            resourceTypes: [ 'sub_frame' ],
            thirdPartyOnly: true,
        },
        // Global Privacy Control securitySlots entry REMOVED — the feature
        // was removed entirely (see dnr-budgets.js's retired-range note for
        // 12 000 000 / GPC_RULES_RETIRED_BASE_ID for why, and CHANGELOG for
        // the full history). One-time cleanup of any pre-existing install's
        // leftover dynamic rule lives in background.js's
        // runVersionMigration(), not here — this reconciliation loop only
        // ever manages currently-defined slots, the same as every other
        // retired range in this project.
    ];

    for ( const slot of securitySlots ) {
        if ( slot.enabled ) {
            const condition = {};
            if ( slot.regexFilter ) {
                condition.regexFilter = slot.regexFilter;
                condition.isUrlFilterCaseSensitive = false;
            }
            if ( slot.resourceTypes ) {
                condition.resourceTypes = slot.resourceTypes;
            }
            if ( slot.requestDomains ) {
                condition.requestDomains = slot.requestDomains;
            }
            if ( slot.thirdPartyOnly !== false ) {
                condition.domainType = 'thirdParty';
            }
            if ( slot.excludedRequestDomains ) {
                condition.excludedRequestDomains = slot.excludedRequestDomains;
            }
            // Apply per-toggle allowlist: exempt these initiator domains.
            const allowed = parseAllowlistDomains(securityAllowlist[slot.allowlistKey]);
            if ( allowed.length > 0 ) {
                condition.excludedInitiatorDomains = allowed;
            }
            addRules.push({
                id: slot.id,
                priority: slot.priority ?? SECURITY_RULES_PRIORITY,
                // modifyHeaders carries its header-list under the action
                // object itself (requestHeaders/responseHeaders), unlike
                // block/allow which need nothing beyond { type }. No slot
                // currently uses this (GPC, the only prior user, was
                // removed — see dnr-budgets.js) but the branch is kept:
                // generic, reusable infrastructure, not GPC-specific logic.
                action: slot.action === 'modifyHeaders'
                    ? { type: 'modifyHeaders', requestHeaders: slot.requestHeaders }
                    : { type: slot.action ?? 'block' },
                condition,
            });
        } else if ( currentIds.has(slot.id) ) {
            removeRuleIds.push(slot.id);
        }
    }

    // Remove slots being replaced before adding new versions
    const toRemove = addRules.map(r => r.id).filter(id => currentIds.has(id));
    const allRemove = [ ...new Set([ ...removeRuleIds, ...toRemove ]) ];

    if ( allRemove.length !== 0 || addRules.length !== 0 ) {
        await dnr.updateDynamicRules({
            removeRuleIds: allRemove,
            addRules,
        }).catch(reason => {
            console.error(`[uBlock-Dynamic] updateSecurityRules/${reason}`);
        });
    }
}

/******************************************************************************/
// Icon badge count visibility — single source of truth, called at startup
// (background.js's startSession()). Previously also accounted for
// Global Privacy Control — see CHANGELOG for the full history: GPC's DNR
// rule (a modifyHeaders match) was counted by Chrome's own badge the same
// as a real block, making the badge deeply misleading whenever GPC was
// on. Fixing that accurately (without either weakening GPC's spec-
// required scope, or building a whole separate webRequest-based counter
// just for this one toggle) wasn't achievable simply, so GPC was removed
// as a feature entirely instead. This function is back to trivial —
// kept as a real function (not inlined at the one call site) because a
// second call site may reasonably exist again in the future.
export async function applyBadgeCountVisibility() {
    if ( typeof dnr.setExtensionActionOptions !== 'function' ) { return; } // Firefox — no-op, same guard background.js already had
    await dnr.setExtensionActionOptions({
        displayActionCountAsBadgeText: rulesetConfig.showBlockedCount,
    }).catch(() => {});
}

/******************************************************************************/

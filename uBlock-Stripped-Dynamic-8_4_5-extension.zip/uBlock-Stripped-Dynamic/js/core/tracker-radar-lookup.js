/*
 * tracker-radar-lookup.js — Domain -> known-tracker lookup
 *
 * Public interface:
 *   lookupTracker(domain)   — returns { owner, onPGL, fingerprinting }
 *                             or null
 *   resetTrackerRadarCache() — drops the built lookup Map (release guard;
 *                              forces a fresh rebuild on next lookup — used
 *                              after a dataset update ships, or by tests)
 *
 * Wraps js/data/tracker-radar-data.js (the compacted DuckDuckGo Tracker
 * Radar dataset — see that file's header for build parameters/provenance).
 *
 * Only ever consulted from matrix-panel.js (uBlock-Stripped-Dynamic's
 * Matrix panel — the standalone "DDG Tracker Radar" Block Monitor session
 * that originally used this module was removed; this data/lookup module
 * survives independently and is now reused for the Matrix panel's own
 * breakage-risk column instead). This module does nothing on its
 * own; it has no listeners, no timers, no background activity. The Map below is built once
 * on first lookup (lazy init guard) and kept for the service worker's
 * lifetime — cheap enough (2,082 entries) that rebuilding per session would
 * be wasted work, but the module still exposes an explicit release path.
 */

import { TRACKER_RADAR_DATA } from '../data/tracker-radar-data.js';

/******************************************************************************/
// Lazy-built lookup Map. null until first use (init guard below).
/******************************************************************************/

let domainToTrackerInfo = null;

function ensureBuilt() {
    if ( domainToTrackerInfo !== null ) { return; }

    domainToTrackerInfo = new Map();
    const { entities, domains } = TRACKER_RADAR_DATA;

    for ( const domain in domains ) {
        const [ entityIndex, onPGL, fingerprinting ] = domains[domain];
        domainToTrackerInfo.set(domain, {
            owner: entities[entityIndex] ?? 'Unknown',
            // Peter Lowe's Ad and tracking server list membership (exact
            // domain match) — the Matrix panel's breakage-risk GREEN
            // signal. See tracker-radar-data.js's header for full
            // provenance; this used to be a numeric 'prevalence' field,
            // dropped in favor of this more directly actionable boolean.
            onPGL,
            // DDG's own 0-3 fingerprinting-API-use score — see
            // js/data/tracker-radar-data.js's header comment for exactly
            // what each level means. Drives the monitor panel's API-misuse
            // color indicator.
            fingerprinting,
        });
    }
}

/******************************************************************************/
// Public API
/******************************************************************************/

// domain is expected to already be reduced to eTLD+1 (see
// matrix-classifier.js's etldPlusOne) — this module does no normalization of
// its own, to avoid a second copy of that suffix logic.
export function lookupTracker(domain) {
    ensureBuilt();
    return domainToTrackerInfo.get(domain) ?? null;
}

// Release guard: drop the built Map so the next lookup rebuilds it fresh.
// Not called during normal operation today — exposed for a future
// "dataset updated, don't wait for SW restart" path and for tests.
export function resetTrackerRadarCache() {
    domainToTrackerInfo = null;
}

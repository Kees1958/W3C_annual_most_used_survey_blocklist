/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock
*/
/*
 * config.js — Extension configuration loading and persistence
 *
 * Public interface:
 *   loadRulesetConfig()      — loads rulesetConfig from storage on SW startup
 *   saveRulesetConfig()      — persists rulesetConfig to chrome.storage.local
 *   saveSecurityConfig()     — persists securityConfig to chrome.storage.local
 *   rulesetConfig {Object}   — runtime config (version, autoReload, showBlockedCount, etc.)
 *   securityConfig {Object}  — security/privacy toggle states
 *   swLifecycle {Object}     — SW lifecycle state vector (phase, startPhase, firstRun, wakeupRun)
 *   SW_PHASES {Object}       — frozen enum of valid swLifecycle.phase values
 *   process                  — alias for swLifecycle (backward compat)
 *
 * Persisted: chrome.storage.local (full) + chrome.storage.session (fast wakeup cache)
 */


import {
    localRead, localWrite,
    sessionRead, sessionWrite,
} from './ext.js';

/******************************************************************************/

export const rulesetConfig = {
    version: '',
    autoReload: true,
    showBlockedCount: true,
    hasBroadHostPermissions: true,
};

// ─────────────────────────────────────────────────────────────────────────
// Government-domain default allowlist — single shared definition, applied
// to every Security & Privacy toggle below (not just one), since these
// checks are prone to interfering with government portals' session/SSO
// mechanisms. Deliberately a small, verified starter set rather than a
// guess at every country's civic domain scheme:
//   - 'gov'    — covers all US federal .gov sites (e.g. irs.gov, usa.gov)
//   - 'gov.it' — covers all Italian public-administration sites (e.g.
//                agenziaentrate.gov.it), the concrete case that prompted
//                this — see CHANGELOG for the specific research.
// allowlistToExcludeMatches() (compiled-filters.js) turns each of these
// into BOTH an exact-host and a '*.'-subdomain match pattern, so listing
// the bare suffix here covers every site under it, not just one example.
// Extend this list the same way any other securityAllowlist entry already
// is — one hostname per line, '#' for comments — if more countries'
// government domains need the same treatment.
const GOV_DOMAIN_ALLOWLIST = [
    '# Government domains',
    'gov',
    'gov.it',
].join('\n');

export const securityConfig = {
    // ── DNR-based toggles (network layer) ────────────────────────────────────
    // blockPunycodeLinks (blocked all-origin punycode links) replaced by
    // blockSuspicious3pLinks in the uBlock-Stripped-Dynamic fork — see
    // js/core/matrix-detect.js for the punycode/IP-literal/non-standard-port
    // predicates this toggle's DNR rules mirror, and ruleset-manager.js's
    // securitySlots for the actual rule composition. Scoped to third-party
    // only now (was all-origin before). A 4th pattern — known DDNS/free-
    // hosting domains — was originally its own separate toggle
    // (blockDdnsFreeHosting) but was folded into this one: both share the
    // same "suspicious 3P link" intent, and splitting them into two
    // checkboxes just meant two toggles to remember to enable instead of
    // one. See runVersionMigration() in background.js for the one-time
    // migration that carries an existing install's separate on/off state
    // for the two forward into this single combined toggle.
    blockSuspicious3pLinks: false,
    // Default OFF = the login-with SSO exemption (see
    // js/data/login-with-exceptions.js) is ACTIVE by default — checking
    // this box is what turns OFF the exemption, blocking those domains
    // like any other third party. Lives in securityConfig (not its own
    // separate config object) purely to reuse the existing
    // getSecurityConfig/setSecurityConfig plumbing and updateSecurityRules()
    // trigger — see ruleset-manager.js's login-with security slots.
    blockLoginWith: false,
    blockWebBundles:         false,
    // ── Scriptlet-based toggles (MAIN world, browser.scripting API) ───────────
    blockPings:              false,
    blockAlertDialogs:       false,
    blockConfirmDialogs:     false,
    blockObfuscatedEval:     false,
    blockAdultNoEval:        false,
    // Applies every fingerprinting-detection mitigation Privacy Inspector
    // knows how to apply (canvas, WebGL, WebGL-fingerprint, audio, timezone,
    // navigator.plugins, device info, WebRTC) directly to the same curated
    // high-risk site list blockAdultNoEval already uses — see
    // SECURITY_SCRIPTLET_BUILTIN_MATCHES.blockAdultFingerprinting in
    // compiled-filters.js (shared constant, not a second copy of the list).
    blockAdultFingerprinting: false,
    // Global Privacy Control was REMOVED (see CHANGELOG) — its DNR rule's
    // required broad scope (first-party AND third-party, unlike every
    // other Security toggle) made Chrome's icon badge count deeply
    // misleading whenever it was on (Chrome counts modifyHeaders matches
    // the same as real blocks), and no accurate-yet-simple fix existed
    // that didn't add real complexity for a single toggle. Removed rather
    // than shipped with a known-misleading side effect.
    // Startup-only action — no scriptlet, no DNR rule. Consulted exactly
    // once per genuine browser launch (browser.runtime.onStartup, NOT the
    // routine MV3 service-worker sleep/wake cycle — see history-cleaner.js
    // and background.js's onStartup listener for why that distinction
    // matters here specifically). "Except passwords": chrome.browsingData's
    // own `passwords` dataToRemove key is deliberately never set true by
    // this feature — see history-cleaner.js for exactly which data types
    // are (and are not) cleared, inspired by (not a copy of)
    // github.com/dessant/clear-browsing-data's approach.
    deleteHistoryOnStart: false,
    // NOTE: the former autoApplyPrivacyExtras manual toggle has been removed
    // (7.0.0) — see applyPrivacyExtrasForHost() in js/core/custom-scriptlets.js,
    // which now applies unconditionally on "Block All" instead of being gated
    // on a dashboard checkbox here.
};

// Per-toggle hostname allowlists — comma or newline separated hostnames.
// DNR toggles: hostnames added to excludedInitiatorDomains on the DNR rule.
// Scriptlet toggles: hostnames added to excludeMatches on the content script directive
//   (the scriptlet simply does not run on those pages).
export const securityAllowlist = {
    blockSuspicious3pLinks: GOV_DOMAIN_ALLOWLIST,
    blockWebBundles:         GOV_DOMAIN_ALLOWLIST,
    blockPings:              GOV_DOMAIN_ALLOWLIST,
    blockAlertDialogs:       GOV_DOMAIN_ALLOWLIST,
    blockConfirmDialogs:     GOV_DOMAIN_ALLOWLIST,
    blockObfuscatedEval:     GOV_DOMAIN_ALLOWLIST,
    blockAdultNoEval:        GOV_DOMAIN_ALLOWLIST,
    // blockAdultFingerprinting intentionally has no allowlist entry here: it
    // is already scoped to a fixed high-risk site list (not applied broadly,
    // nothing to exempt sites from).
};

// Re-exported so background.js's one-time version-migration step (the
// established place in this codebase for "existing users' saved config
// needs a new default retroactively applied") can append the exact same
// list to already-installed users' saved allowlists, instead of this only
// taking effect for fresh installs. See runVersionMigration() there.
export { GOV_DOMAIN_ALLOWLIST };

export const defaultConfig = Object.assign({}, rulesetConfig);

/******************************************************************************/
// SW lifecycle state vector
// Applies the same swimming-lane pattern used in block-monitor.js.
//
// Phases (SW startup lane — one linear sequence per SW lifetime):
//
//   [booting] — loadRulesetConfig() in progress; no config available yet
//       │
//       ▼
//   [starting] — startSession() in progress; config loaded, rules being applied
//       │  startPhase tracks the sub-step within starting:
//       │    'migration'   — runVersionMigration() running
//       │    'locale'      — enableLocaleLanguageFilter() running
//       │    'permissions' — syncWithBrowserPermissions() running
//       │    'scripts'     — registerContentScripts/UserScripts running
//       │    'finalising'  — security rules, badge, AG data loading
//       │
//       ├──(success)──► [ready]  — fully initialised; all event listeners active
//       │
//       └──(throw)────► [error]  — start() threw; errorReason holds the message
//                                  Chrome may attempt a one-shot reload (goodStart guard)
//
// The `phase` field is the authoritative signal used by all isFullyInitialized
// consumers. The three boolean flags (firstRun, wakeupRun, firstAlarm) are
// retained as named fields on the same vector so background.js call sites
// need no mass rename.
/******************************************************************************/

export const SW_PHASES = Object.freeze({
    BOOTING:  'booting',
    STARTING: 'starting',
    READY:    'ready',
    ERROR:    'error',
});

export const swLifecycle = {
    owner:       'background',
    phase:       SW_PHASES.BOOTING,
    startPhase:  null,      // sub-step within STARTING, null otherwise
    errorReason: null,      // set on ERROR, null otherwise
    // Boot-time flags — set once by loadRulesetConfig, never change after
    firstRun:    false,     // true  → fresh install (no prior rulesetConfig in storage)
    wakeupRun:   false,     // true  → SW restarted mid-session (session storage present)
    firstAlarm:  false,     // true  → first alarm tick after a wakeup has been handled
};

// Backward-compat alias — existing `process.firstRun` / `process.wakeupRun`
// references in background.js continue to work without a mass rename.
export const process = swLifecycle;

let pendingOpPromise = Promise.resolve();

/******************************************************************************/

async function _loadRulesetConfig() {
    const sessionData = await sessionRead('rulesetConfig');
    if ( sessionData ) {
        Object.assign(rulesetConfig, sessionData);
        process.wakeupRun = true;
    } else {
        const localData = await localRead('rulesetConfig');
        if ( localData ) {
            Object.assign(rulesetConfig, localData);
        }
        sessionWrite('rulesetConfig', rulesetConfig);
        if ( !localData ) {
            localWrite('rulesetConfig', rulesetConfig);
            process.firstRun = true;
        }
    }
    const savedSecurity = await localRead('securityConfig');
    if ( savedSecurity ) {
        Object.assign(securityConfig, savedSecurity);
    } else {
        localWrite('securityConfig', securityConfig);
    }
    const savedAllowlist = await localRead('securityAllowlist');
    if ( savedAllowlist ) {
        Object.assign(securityAllowlist, savedAllowlist);
    } else {
        localWrite('securityAllowlist', securityAllowlist);
    }
}

async function _saveRulesetConfig() {
    sessionWrite('rulesetConfig', rulesetConfig);
    return localWrite('rulesetConfig', rulesetConfig);
}

export async function saveSecurityConfig() {
    return localWrite('securityConfig', securityConfig);
}

export async function saveSecurityAllowlist() {
    return localWrite('securityAllowlist', securityAllowlist);
}

/******************************************************************************/

export function loadRulesetConfig() {
    pendingOpPromise = pendingOpPromise.then(_loadRulesetConfig);
    return pendingOpPromise;
}

export function saveRulesetConfig() {
    pendingOpPromise = pendingOpPromise.then(_saveRulesetConfig);
    return pendingOpPromise;
}

/*
 * login-with-exceptions.js — "Sign in with X" SSO domain exceptions
 *
 * Public interface:
 *   LOGIN_WITH_DOMAINS       — flat array of every domain in this list
 *   LOGIN_WITH_SCRIPT_DOMAINS — domains needing the script exemption
 *   LOGIN_WITH_FRAME_DOMAINS  — domains needing the sub_frame exemption
 *   LOGIN_WITH_CATEGORY      — domain -> provider name, for tooltips
 *
 * Ported from a provided spec: 18 domains across Apple, Google, Meta,
 * GitHub, LinkedIn, Microsoft, and general auth-as-a-service providers
 * (Auth0, Okta, OneLogin, OpenAI, WorkOS) — each needed for "Sign in
 * with X" / OAuth login flows that would otherwise break if these
 * domains were blocked as generic third-party trackers.
 *
 * The source spec marks these "per_top_level_site" / "user_initiated_login"
 * scoped — i.e. ideally only exempted on the specific site currently
 * attempting a login, only while the user is actively doing so. That
 * requires detecting genuine user-initiated login intent (e.g. a click on
 * an actual login button) — DNR can't express that declaratively, and
 * building real click-intent detection is a much larger feature than
 * "add a checkbox to Filter (block) lists". Implemented here as a global,
 * always-on-unless-toggled-off exemption instead (see
 * js/core/ruleset-manager.js's login-with security slots) — the
 * "Block login-with (google, facebook, etc)" checkbox on the Filter
 * (block) lists page controls it, default OFF (i.e. the exemption is
 * active by default, matching the source spec's intent that these
 * shouldn't be blocked as generic trackers).
 */

export const LOGIN_WITH_CATEGORY = Object.freeze({
    'appleid.apple.com':         'Apple',
    'idmsa.apple.com':           'Apple',
    'accounts.google.com':       'Google',
    'apis.google.com':           'Google',
    'content.googleapis.com':    'Google',
    'connect.facebook.net':      'Meta/Facebook',
    'facebook.com':              'Meta/Facebook',
    'github.com':                'GitHub',
    'linkedin.com':              'LinkedIn',
    'account.microsoft.com':     'Microsoft',
    'login.live.com':            'Microsoft',
    'login.microsoftonline.com': 'Microsoft',
    'login.windows.net':         'Microsoft',
    'auth0.com':                 'Auth-as-a-service',
    'okta.com':                  'Auth-as-a-service',
    'onelogin.com':              'Auth-as-a-service',
    'openai.com':                'Auth-as-a-service',
    'workos.com':                'Auth-as-a-service',
});

export const LOGIN_WITH_DOMAINS = Object.freeze(Object.keys(LOGIN_WITH_CATEGORY));

export const LOGIN_WITH_SCRIPT_DOMAINS = Object.freeze([
    'apis.google.com',
    'content.googleapis.com',
    'connect.facebook.net',
    'auth0.com',
    'okta.com',
    'onelogin.com',
    'openai.com',
    'workos.com',
]);

export const LOGIN_WITH_FRAME_DOMAINS = Object.freeze([
    'appleid.apple.com',
    'idmsa.apple.com',
    'accounts.google.com',
    'facebook.com',
    'github.com',
    'linkedin.com',
    'account.microsoft.com',
    'login.live.com',
    'login.microsoftonline.com',
    'login.windows.net',
    'auth0.com',
    'okta.com',
    'onelogin.com',
    'openai.com',
    'workos.com',
]);

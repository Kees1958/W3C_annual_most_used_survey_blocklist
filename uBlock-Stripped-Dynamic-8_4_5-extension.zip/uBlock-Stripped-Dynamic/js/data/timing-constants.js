/*
 * timing-constants.js — shared timing values used by more than one feature
 *
 * Public interface: numeric constants only. No logic, no state.
 */

/*******************************************************************************

    DEFAULT_SESSION_TIMEOUT_MS
    ---------------------------
    Block Monitor and Privacy Inspector each independently chose a 5-minute
    session timeout — same value, but a coincidence of two unrelated
    features, not a structural coupling between them (uBol-stripped-
    code-review.md §2). Named once here so the literal itself can't drift
    out of sync between the 4 places that used it (js/core/block-monitor.js,
    js/core/privacy-inspector.js, monitor/monitor-panel.js,
    privacy/privacy-inspector.js's own SW-side guard and UI-side countdown
    display for each feature).

    Each consumer still assigns this to its own locally-named constant
    (e.g. `const SESSION_TIMEOUT_MS = DEFAULT_SESSION_TIMEOUT_MS;`) rather
    than importing and using DEFAULT_SESSION_TIMEOUT_MS directly everywhere
    — so a future feature can deliberately diverge from this default later
    by simply no longer importing it, without this file's name implying
    the two timeouts must always match.

*******************************************************************************/
export const DEFAULT_SESSION_TIMEOUT_MS = 5 * 60 * 1000;

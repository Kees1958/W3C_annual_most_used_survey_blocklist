/*******************************************************************************

    uBol-stripped — Allow list editor (dashboard Allow list tab)

    The CodeMirror editor shows and edits a plain list of domains for which
    filtering is turned off (allow-listed). One domain per line.

    Internally these map to siteModes entries with mode 0 (no-filtering).
    All other domains remain at the default mode 1 (basic / on).

*******************************************************************************/

import {
    siteModesFromText,
    textFromSiteModes,
} from '../util/site-mode-parser.js';
import { sendMessage } from '../data/ext.js';

/******************************************************************************/

export class ModeEditor {
    constructor(editor) {
        this.editor = editor;
        this.bc = null;
    }

    on() {}
    off() {}

    async getText() {
        const siteModes = await sendMessage({ what: 'siteModeGetAll' });
        // sendMessage() resolves to `undefined` when every retry attempt
        // failed (SW not ready, messaging error, etc.) — indistinguishable
        // by value from a legitimate empty {} response otherwise. Throwing
        // here (instead of defaulting to {}) lets the caller (develop.js)
        // tell the difference and refuse to show an editable-and-savable
        // blank editor that could silently overwrite the real stored list.
        if ( siteModes === undefined ) {
            throw new Error('siteModeGetAll: no response from background');
        }
        return textFromSiteModes(siteModes);
    }

    async saveEditorText(editor) {
        const text = editor.getEditorText();
        const siteModes = siteModesFromText(text);
        const saved = await sendMessage({ what: 'siteModeSetAll', siteModes });
        // Same undefined-means-failure distinction as getText() above:
        // handleSiteModeSetAll (background.js) always resolves with an
        // object on success — {} only for a genuinely empty list, never
        // undefined — so undefined here means the message itself failed.
        // Report failure rather than silently marking the editor "saved".
        if ( saved === undefined ) {
            console.error('[uBlock-Dynamic] Allow list editor: save failed — no response from background');
            return false;
        }
        editor.setEditorText(textFromSiteModes(saved));
        return true;
    }

    updateView(editor, firstLine, lastLine) {
        // No inline validation needed — plain domain list
    }

    // No newlineAssistant: plain list needs no auto-indentation prefix
}

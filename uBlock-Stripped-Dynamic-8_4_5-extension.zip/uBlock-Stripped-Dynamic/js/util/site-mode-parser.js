/*******************************************************************************

    uBol-stripped — Allow list parser / serialiser

    Parses and serialises the plain domain list used in the Allow list
    dashboard editor.

    Format: one domain per line, blank lines and lines starting with # ignored.

    Internal representation: { [hostname]: 0 }
    All listed domains are mapped to mode 0 (no-filtering / off).

    Values:
      0 = OFF   / no-filtering  (the only mode exposed here)
      1 = BASIC / on            (the global default for unlisted domains)

*******************************************************************************/
/*
 * site-mode-parser.js -- plain-list serialiser/parser for the allow list editor
 *
 * Public interface:
 *   siteModesFromText(text)    -- parses plain list -> {hostname: 0} object
 *   textFromSiteModes(modes)   -- serialises {hostname: mode} -> plain list
 *   SECTION_NAMES              -- kept for compatibility (single-entry array)
 *
 * No state. No side effects. Pure serialisation utility.
 */


import punycode from './punycode.js';

/******************************************************************************/

// Kept for compatibility with mode-editor.js newlineAssistant lookup.
// Only one implicit "section" now — the domain list itself.
export const SECTION_NAMES = ['allow-list'];

/******************************************************************************/

export function siteModesFromText(text) {
    const out = {};

    for ( const rawLine of text.split(/\n|\r\n|\r/) ) {
        const trimmed = rawLine.trim();

        // Skip blank lines and comments
        if ( trimmed === '' || trimmed.startsWith('#') ) { continue; }

        const raw = trimmed.toLowerCase();
        const hn  = punycode.toASCII(raw);
        if ( hn.length > 0 && hn.length <= 253 ) {
            // All listed domains are no-filtering (mode 0)
            out[hn] = 0;
        }
    }

    return out;
}

/******************************************************************************/

export function textFromSiteModes(siteModes) {
    const domains = [];

    for ( const [hn, mode] of Object.entries(siteModes) ) {
        // Only emit domains that are explicitly turned off (mode 0)
        if ( mode !== 0 ) { continue; }
        // Skip the internal sentinel; it has no meaning in the plain list
        if ( hn === 'all-urls' ) { continue; }
        domains.push(punycode.toUnicode(hn));
    }

    domains.sort((a, b) => a.localeCompare(b));
    return domains.length > 0 ? domains.join('\n') + '\n' : '';
}

/******************************************************************************/

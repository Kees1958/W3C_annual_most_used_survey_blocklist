/*******************************************************************************

    uBlock Origin Lite - a comprehensive, MV3-compliant content blocker
    Copyright (C) 2022-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

*******************************************************************************/

import { browser, runtime, sendMessage, localWrite } from '../js/data/ext.js';
import { MSG_START_MATRIX, MSG_START_PRIVACY_INSPECTOR } from '../js/data/message-types.js';
import { MODE_NONE } from '../js/core/mode-manager.js';

/******************************************************************************/

import { dom, qs$ } from '../js/ui/dom.js';

/******************************************************************************/

const currentTab = {};
const tabURL = new URL(runtime.getURL('/'));

/******************************************************************************/

function displayHostname(hostname) {
    return hostname.replace(/^www\./, '');
}

/******************************************************************************/

// ── Combined status-bar state ──────────────────────────────────────────────
// Two independent inputs feed the single #statusText/#statusIcon display:
//   1. `lastIsOff`       — the current SITE's own on/off state (set by
//                          site-mode-ui.js's render(), and by init() below
//                          from the initial popupPanelData fetch).
//   2. `tempDisableActive` — the GLOBAL temporary-pause state (set by
//                          temp-disable-ui.js), which is independent of any
//                          single site and, while active, overrides the
//                          displayed text regardless of the current site's
//                          own setting.
// Both are tracked here (not recomputed from scratch on every call) so
// either module can update its own input at any time — e.g. the countdown
// panel expiring — without needing to know or re-fetch the other one.
let lastIsOff = false;
let tempDisableActive = false;

function renderState(isOff = false) {
    lastIsOff = isOff;
    const isHTTP = tabURL.protocol === 'http:' || tabURL.protocol === 'https:';
    const statusText = qs$('#statusText');
    const statusIcon = qs$('#statusIcon');
    if ( !isHTTP ) {
        if ( statusText ) { statusText.textContent = 'Not applicable'; }
        if ( statusIcon ) { statusIcon.classList.remove('status-off'); }
    } else if ( tempDisableActive ) {
        // Same OFF icon as the plain "Filtering off" case below — visually
        // it IS off — but distinct text: this is a timed pause, not the
        // user having deliberately turned filtering off for this site.
        if ( statusText ) { statusText.textContent = 'Filtering temporarily disabled'; }
        if ( statusIcon ) { statusIcon.classList.add('status-off'); }
    } else if ( isOff ) {
        if ( statusText ) { statusText.textContent = 'Filtering off'; }
        if ( statusIcon ) { statusIcon.classList.add('status-off'); }
    } else {
        if ( statusText ) { statusText.textContent = 'Filtering active'; }
        if ( statusIcon ) { statusIcon.classList.remove('status-off'); }
    }
}

// Called by temp-disable-ui.js whenever the global pause starts, ends
// early, or expires — re-renders using whatever the current site's own
// isOff state already was, so this never has to re-fetch it.
export function setTempDisableActive(active) {
    tempDisableActive = active;
    renderState(lastIsOff);
}

/******************************************************************************/

// BUG FIX: Chrome sometimes spawns an extra blank tab (chrome://newtab/ or
// about:blank) in the same new window alongside the one we actually asked
// for in windows.create() — a known Chrome quirk, previously just tolerated
// as unavoidable. windows.create()'s resolved Window object already
// includes the tabs it just created, so we can detect and close whichever
// one isn't ours instead of leaving it behind.
async function openOrFocusPanel(url) {
    const existing = await browser.tabs.query({ url });
    if ( existing.length > 0 ) {
        browser.windows.update(existing[0].windowId, { focused: true });
        return;
    }
    const win = await browser.windows.create({
        url,
        type: 'popup',
        // Calculated, not guessed, from two competing constraints:
        //   1. #monitorHelp's explanatory paragraph ("Shows privacy-
        //      sensitive API calls..."), 151 characters at 0.82em regular
        //      weight, needs ~889px to fit on one line without wrapping.
        //   2. The "Show:" filter bar (12 checkboxes after the
        //      Legitimate-signals merge) needs only ~771px minimum to
        //      stay at 2 lines — well under constraint 1's requirement,
        //      so it isn't the binding constraint here.
        // 916px satisfies both (889px + ~3% margin), confirmed by
        // re-running the filter-bar line-fill simulation at this width
        // (still exactly 2 lines, not 1, not 3). Re-measure both if either
        // #monitorHelp's text or SHORT_LABELS/FILTER_GROUPS changes again.
        width: 916,
        height: 540,
        focused: true,
    });
    // BUG FIX: comparing tabs[i].url/pendingUrl against `url` here is
    // unreliable — navigation to `url` may not have committed yet by the
    // time this promise resolves, so the *real* tab's url/pendingUrl can
    // still be empty at this exact moment, and the previous version of
    // this filter misidentified and closed that real tab every time
    // (not just when Chrome actually added a ghost one). The tab we asked
    // for is reliably the first one in the array; only remove anything
    // beyond that, by position, not by URL.
    const extraTabs = (win?.tabs ?? []).slice(1);
    if ( extraTabs.length > 0 ) {
        await browser.tabs.remove(extraTabs.map(t => t.id)).catch(() => {});
    }

    // SECOND PASS, delayed: the check above only catches a ghost tab
    // Chrome has already added by the moment windows.create()'s promise
    // resolves. If Chrome adds one slightly later instead — plausible,
    // not verified against a specific Chromium bug number, but the
    // failure shape ("an empty tab" that persists with no session,
    // timeout, or watchdog ever attached to it, since nothing in this
    // codebase's panel-lifecycle machinery tracks tabs it doesn't know
    // it created) matches this timing gap better than the same-instant
    // race the first pass already covers — the first pass would silently
    // miss it, and it would then sit there indefinitely: not the real
    // panel (which has its own session/watchdog/poll triple redundancy —
    // see C21 in the principles doc), just an orphaned blank tab this
    // function itself is responsible for, with nothing else positioned
    // to ever notice or close it. Re-check once, after a short delay,
    // and clean up anything new — belt-and-suspenders alongside the
    // synchronous check above, not a replacement for it.
    setTimeout(async () => {
        const stillThere = await browser.tabs.query({ windowId: win.id }).catch(() => []);
        const lateGhosts = stillThere.slice(1);
        if ( lateGhosts.length > 0 ) {
            await browser.tabs.remove(lateGhosts.map(t => t.id)).catch(() => {});
        }
    }, 800);
}

/******************************************************************************/

dom.on('#gotoPrivacyInspector', 'click', async ev => {
    if ( ev.isTrusted !== true || ev.button !== 0 ) { return; }
    await sendMessage({ what: MSG_START_PRIVACY_INSPECTOR, tabId: currentTab.id });
    await openOrFocusPanel(runtime.getURL('privacy/privacy-inspector.html'));
    self.close();
});

dom.on('#gotoMatrixPanel', 'click', async ev => {
    if ( ev.isTrusted !== true ) { return; }
    if ( ev.button !== 0 ) { return; }
    await sendMessage({ what: MSG_START_MATRIX, tabId: currentTab.id });
    await openOrFocusPanel(runtime.getURL('matrix/matrix-panel.html'));
    self.close();
});

dom.on('#gotoCustomRules', 'click', ev => {
    if ( ev.isTrusted !== true ) { return; }
    if ( ev.button !== 0 ) { return; }
    localWrite('dashboard.activePane', 'customrules');
    runtime.openOptionsPage();
});

dom.on('#gotoFilterLists', 'click', ev => {
    if ( ev.isTrusted !== true ) { return; }
    if ( ev.button !== 0 ) { return; }
    localWrite('dashboard.activePane', 'filterlists');
    runtime.openOptionsPage();
});

dom.on('#gotoDashboard', 'click', ev => {
    if ( ev.isTrusted !== true ) { return; }
    if ( ev.button !== 0 ) { return; }
    localWrite('dashboard.activePane', 'filters');
    runtime.openOptionsPage();
});

dom.on('#gotoFilteringMode', 'click', ev => {
    if ( ev.isTrusted !== true ) { return; }
    if ( ev.button !== 0 ) { return; }
    localWrite('dashboard.activePane', 'develop');
    runtime.openOptionsPage();
});

dom.on('#gotoSecurity', 'click', ev => {
    if ( ev.isTrusted !== true ) { return; }
    if ( ev.button !== 0 ) { return; }
    localWrite('dashboard.activePane', 'security');
    runtime.openOptionsPage();
});

dom.on('#gotoPicker', 'click', ( ) => {
    if ( browser.scripting === undefined ) { return; }
    browser.scripting.executeScript({
        files: [
            '/js/scripting/css-procedural-api.js',
            '/js/scripting/tool-overlay.js',
            '/js/scripting/picker.js',
        ],
        target: { tabId: currentTab.id },
    });
    self.close();
});

// Cookie/consent-clicker picker — see COOKIE-CLICKER-DESIGN.md for the
// full design history. The actual detect/toggle/inject sequence
// (D6/D10) lives in js/workflow/cookie-clicker-routes.js's own
// handleCookieClickerLaunchPicker() as of 8.2.17 — moved out of this
// popup entirely. See that function's own header for the full
// reasoning, in short: this popup window closes the instant it loses
// focus, and the detection step's own bounded retry (8.2.9, up to
// ~1.5s across every frame) made running that sequence HERE vulnerable
// to being silently abandoned mid-flight if the popup closed before it
// finished — the real cause behind "sometimes I have to click a few
// times before it starts." Firing one message and closing immediately,
// without awaiting a response, decouples this popup's own (unreliable)
// lifetime from that work entirely — once dispatched, the background
// service worker keeps running it to completion regardless of whether
// this popup still exists a moment later.
dom.on('#gotoCookieClicker', 'click', ( ) => {
    if ( browser.scripting === undefined ) { return; }
    sendMessage({ what: 'cookieClickerLaunchPicker', tabId: currentTab.id });
    self.close();
});


/******************************************************************************/

async function init() {
    const [ tab ] = await browser.tabs.query({
        active: true,
        currentWindow: true,
    });
    if ( tab instanceof Object === false ) { return true; }
    Object.assign(currentTab, tab);

    let url;
    try {
        url = new URL(currentTab.url);
        tabURL.href = url.href || '';
    } catch {
        return false;
    }

    // Fetch popup data — includes the site's current filtering level.
    const response = await sendMessage({
        what: 'popupPanelData',
        origin: url.origin,
        hostname: tabURL.hostname,
    });

    const isHTTP = url.protocol === 'http:' || url.protocol === 'https:';
    dom.cl.toggle(dom.root, 'isHTTP', isHTTP);

    // BUG FIX: this element was always left blank — displayHostname() was
    // defined but never actually called anywhere (found via ESLint
    // no-unused-vars). See uBol-stripped-code-review.md §3c.
    const hostnameEl = qs$('#siteModeHostname');
    if ( hostnameEl ) {
        hostnameEl.textContent = displayHostname(tabURL.hostname);
    }

    // BUG FIX: renderState() used to be called with no argument here, so
    // its `isOff` parameter always defaulted to false — the popup's status
    // text showed "Filtering active" unconditionally, even on a site where
    // filtering was actually off. `response` (the site's real filtering
    // level) was fetched above and silently discarded (also found via
    // ESLint no-unused-vars). MODE_NONE (0) is mode-manager.js's own
    // "no filtering" value — see its MODE_NONE/MODE_BASIC definitions.
    renderState(response?.level === MODE_NONE);
    return true;
}

export { renderState };
const INIT_RETRY_MAX_ATTEMPTS = 20;
// Chosen default: init() fails when the service worker hasn't finished
// waking up yet (cold-start race right after browser launch) — this delay
// gives it breathing room between retries instead of busy-looping.
// Found via ESLint (no-undef): this constant was referenced below but
// never declared, so setTimeout was silently getting `undefined` (coerced
// to 0ms) — the retry loop had no actual delay at all. 150ms × up to 20
// attempts keeps the worst-case wait under ~3s, matching the timescale of
// a service-worker cold start rather than a network round-trip.
const INIT_RETRY_DELAY_MS = 150;

async function tryInit(attempt = 0) {
    try {
        await init();
    } catch {
        if ( attempt < INIT_RETRY_MAX_ATTEMPTS ) {
            setTimeout(( ) => tryInit(attempt + 1), INIT_RETRY_DELAY_MS);
        }
    } finally {
        dom.cl.remove(dom.body, 'loading', 'busy');
    }
}

tryInit();

/******************************************************************************/

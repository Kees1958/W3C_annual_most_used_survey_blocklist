/*******************************************************************************

    uBol-stripped — Temporary global disable UI

    Wires the button beneath the site-mode toggle and the 5/10/15/30/60-
    minute duration-picker modal to the js/core/temp-disable-manager.js
    backend (via tempDisableGet/Start/Cancel messages — see
    js/workflow/background.js / message-routes.js). The button itself
    doubles as the live countdown display while a pause is active.

    Unlike site-mode-ui.js's per-site toggle, this is NOT scoped to the
    current tab's hostname — it's a single global on/off switch with a timer,
    so there is no per-hostname state to read here at all.

*******************************************************************************/

import { sendMessage } from '../js/data/ext.js';
import { dom, qs$ } from '../js/ui/dom.js';
import { setTempDisableActive } from './popup.js';

/******************************************************************************/

// ── Config — declared once, here ────────────────────────────────────────
// The 3 duration buttons themselves live in popup.html
// (.tempDisableDurationChoice, data-minutes="…") — they must match
// js/core/temp-disable-manager.js's ALLOWED_DURATIONS_MINUTES exactly.
// There is no shared JS constant between an .html file and this script, so
// the backend is the actual enforcement point (startTempDisable() rejects
// anything else); this UI only ever sends what its own buttons offer.
//
// How often the countdown/count-up display re-renders. 1 second is
// plenty for a minutes-scale timer — no need to tax the popup with
// anything finer.
const COUNTDOWN_TICK_MS = 1000;

/******************************************************************************/
// State
/******************************************************************************/

let selectedMinutes = null;

// Guard: the single live timer (counting down for a timed pause, or up
// for an indefinite one). stopTicker() always clears this before
// startTicker() creates a new one, and it's cleared again whenever the
// button returns to its inactive state (cancelled, expired, or on init
// finding no active pause) — never left running with nothing to update,
// and never silently doubled by a stray extra call to startTicker().
let countdownIntervalId = null;

/******************************************************************************/
// Timer — one shared ticker, two display modes
/******************************************************************************/

function formatClock(totalSeconds) {
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    return `${minutes}:${String(seconds).padStart(2, '0')}`;
}

// Timed pause: counts DOWN to untilMs. ceil so it doesn't visually touch
// 0:00 a tick early.
function formatRemaining(ms) {
    return formatClock(Math.max(0, Math.ceil(ms / 1000)));
}

// Indefinite ("until browser restart") pause: counts UP from
// startedAtMs — there's no end time to count down to. floor so it reads
// 0:00 right at the start, then ticks up naturally.
function formatElapsed(ms) {
    return formatClock(Math.max(0, Math.floor(ms / 1000)));
}

function stopTicker() {
    if ( countdownIntervalId === null ) { return; }
    clearInterval(countdownIntervalId);
    countdownIntervalId = null;
}

function startTicker(tick) {
    stopTicker();   // guard: never stack a second interval over the first
    tick();
    countdownIntervalId = setInterval(tick, COUNTDOWN_TICK_MS);
}

function startCountdown(untilMs) {
    const countdownEl = qs$('#tempDisableButtonCountdown');
    startTicker(( ) => {
        const remainingMs = untilMs - Date.now();
        if ( remainingMs <= 0 ) {
            applyInactiveState();
            return;
        }
        if ( countdownEl ) { countdownEl.textContent = formatRemaining(remainingMs); }
    });
}

function startCountup(startedAtMs) {
    const countdownEl = qs$('#tempDisableButtonCountdown');
    startTicker(( ) => {
        const elapsedMs = Date.now() - startedAtMs;
        if ( countdownEl ) { countdownEl.textContent = formatElapsed(elapsedMs); }
    });
}

/******************************************************************************/
// Button state
/******************************************************************************/

// Tracked so the single #tempDisableButton click handler below knows
// which action it should take — open the duration picker, or end an
// already-active pause — without needing to re-derive it from DOM state.
let isActive = false;

function applyActiveState(untilMs, startedAtMs) {
    isActive = true;
    const labelEl = qs$('#tempDisableButtonLabel');
    const btn = qs$('#tempDisableButton');
    if ( labelEl ) { labelEl.textContent = 'Enable filtering again'; }
    if ( btn ) { btn.classList.add('is-active'); }
    if ( untilMs === null ) {
        startCountup(startedAtMs ?? Date.now());
    } else {
        startCountdown(untilMs);
    }
    setTempDisableActive(true);
}

function applyInactiveState() {
    isActive = false;
    stopTicker();
    const labelEl = qs$('#tempDisableButtonLabel');
    const btn = qs$('#tempDisableButton');
    const countdownEl = qs$('#tempDisableButtonCountdown');
    if ( labelEl ) { labelEl.textContent = 'Pause filtering…'; }
    if ( btn ) { btn.classList.remove('is-active'); }
    // Release guard: clear the leftover countdown text explicitly, rather
    // than leaving a stale "0:00" (or worse, the last real reading)
    // sitting in the DOM the next time the button is inactive.
    if ( countdownEl ) { countdownEl.textContent = ''; }
    setTempDisableActive(false);
}

/******************************************************************************/
// Duration-picker modal
/******************************************************************************/

function resetDurationChoices() {
    selectedMinutes = null;
    for ( const el of document.querySelectorAll('.tempDisableDurationChoice') ) {
        el.classList.remove('is-selected');
    }
    const confirmBtn = qs$('#tempDisableConfirmBtn');
    if ( confirmBtn ) { confirmBtn.disabled = true; }
}

function openModal() {
    resetDurationChoices();
    const modal = qs$('#tempDisableModal');
    if ( modal ) { modal.hidden = false; }
}

function closeModal() {
    const modal = qs$('#tempDisableModal');
    if ( modal ) { modal.hidden = true; }
}

/******************************************************************************/
// Event wiring
/******************************************************************************/

// Small helper so the click handler below and any other future caller
// share exactly one place that actually calls tempDisableCancel.
async function cancelPause() {
    await sendMessage({ what: 'tempDisableCancel' });
    applyInactiveState();
}

// Stop mechanism: the button itself, same principle as the site-mode
// turn-off/turn-on button — one control whose label and action both
// flip with the current state. "Pause filtering…" opens the picker;
// "Enable filtering again" (while active) ends the pause directly.
dom.on('#tempDisableButton', 'click', async ev => {
    if ( ev.isTrusted !== true || ev.button !== 0 ) { return; }
    if ( isActive ) {
        await cancelPause();
        return;
    }
    openModal();
});

dom.on('.tempDisableDurationChoice', 'click', ev => {
    if ( ev.isTrusted !== true || ev.button !== 0 ) { return; }
    const el = ev.currentTarget;
    const minutes = parseInt(el.dataset.minutes, 10);
    if ( !Number.isFinite(minutes) ) { return; }
    selectedMinutes = minutes;
    for ( const choice of document.querySelectorAll('.tempDisableDurationChoice') ) {
        choice.classList.toggle('is-selected', choice === el);
    }
    const confirmBtn = qs$('#tempDisableConfirmBtn');
    if ( confirmBtn ) { confirmBtn.disabled = false; }
});

dom.on('#tempDisableCancelBtn', 'click', ev => {
    if ( ev.isTrusted !== true || ev.button !== 0 ) { return; }
    closeModal();
});

// Clicking the dimmed backdrop (not the picker card itself) also dismisses
// the modal, same as the Cancel button — a plain click-outside-to-close,
// common enough that requiring the Cancel button specifically would be
// more surprising than not.
dom.on('#tempDisableModal', 'click', ev => {
    if ( ev.isTrusted !== true || ev.button !== 0 ) { return; }
    if ( ev.target !== ev.currentTarget ) { return; }   // ignore clicks inside the card
    closeModal();
});

dom.on('#tempDisableConfirmBtn', 'click', async ev => {
    if ( ev.isTrusted !== true || ev.button !== 0 ) { return; }
    if ( selectedMinutes === null ) { return; }
    const confirmBtn = ev.currentTarget;
    confirmBtn.disabled = true;   // guard against a double-submit while the request is in flight
    try {
        const resp = await sendMessage({ what: 'tempDisableStart', minutes: selectedMinutes });
        closeModal();
        if ( resp?.active ) { applyActiveState(resp.untilMs, resp.startedAtMs); }
    } finally {
        confirmBtn.disabled = false;
    }
});

// Indefinite pause — a direct action, not a chip-then-confirm choice:
// clicking it commits immediately, same as the timed picker's Pause
// button does after a duration is selected.
dom.on('#tempDisableUntilRestartBtn', 'click', async ev => {
    if ( ev.isTrusted !== true || ev.button !== 0 ) { return; }
    const btn = ev.currentTarget;
    btn.disabled = true;   // guard against a double-submit while the request is in flight
    try {
        const resp = await sendMessage({ what: 'tempDisableStartUntilRestart' });
        closeModal();
        if ( resp?.active ) { applyActiveState(resp.untilMs, resp.startedAtMs); }
    } finally {
        btn.disabled = false;
    }
});

/******************************************************************************/
// Init
/******************************************************************************/

async function init() {
    const resp = await sendMessage({ what: 'tempDisableGet' });
    if ( resp?.active ) {
        applyActiveState(resp.untilMs, resp.startedAtMs);
    } else {
        applyInactiveState();
    }
}

init();

/******************************************************************************/
